@echo off
REM setup.bat - venv 생성 + 활성화 + requirements 설치를 한 번에 처리
REM 사용법: 프로젝트 루트에서 그냥 더블클릭하거나 cmd/PowerShell에서 setup.bat 실행

echo [1/4] 가상환경(.venv) 생성 중...
python -m venv .venv
if errorlevel 1 (
    echo [에러] venv 생성 실패. python이 PATH에 잡혀있는지 확인하세요.
    pause
    exit /b 1
)

echo [2/4] PowerShell 스크립트 실행 정책 임시 허용 중...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass"

echo [3/4] 가상환경 활성화 중...
call .venv\Scripts\activate.bat
if errorlevel 1 (
    echo [에러] venv 활성화 실패.
    pause
    exit /b 1
)

echo [4/4] requirements.txt 설치 중... (시간이 좀 걸릴 수 있음)
pip install -r requirements.txt
if errorlevel 1 (
    echo [경고] 일부 패키지 설치에 실패했을 수 있습니다. 위 로그를 확인하세요.
) else (
    echo [완료] 설치가 끝났습니다.
)

echo.
echo ==============================================
echo  이 창을 닫아도 .venv는 그대로 남아있습니다.
echo  다음부터 작업할 때는 이렇게 활성화하세요:
echo    PowerShell: .\.venv\Scripts\Activate.ps1
echo    cmd       : .venv\Scripts\activate.bat
echo ==============================================
pause
