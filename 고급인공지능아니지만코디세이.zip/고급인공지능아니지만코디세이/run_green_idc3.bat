@echo off
:: 터미널 창 한글 깨짐 방지
chcp 65001 >nul

:: 프로젝트 폴더 경로로 이동
cd /d "C:\Users\skrkt\Desktop\고급인공지능\2학기\green-idc\green-idc"

:: 모듈 인식 문제 방지
set PYTHONPATH=.

:: 기상청 API 키 (본인 인증키로 교체)
set WEATHER_API_KEY=kDAOBXWkloTgzYhZT9Mf6MnNop1ew5A3z0FBFplKMR%2BF4H3liAuNsBNkrwpywkSAR3NaVGuGcy6bCayLfYN3GA%3D%3D

echo 🚀 Green IDC 시스템을 가동합니다...

:: 1. FastAPI 백엔드 실행 (새 터미널 창 띄우기)
start "Green IDC - FastAPI Backend" cmd /k "uvicorn src.main:app --reload"

:: 백엔드가 완전히 켜질 때까지 조금 더 여유있게 대기
timeout /t 4 /nobreak >nul

:: 2. Streamlit 대시보드 실행 (새 터미널 창 띄우기)
start "Green IDC - Streamlit Dashboard" cmd /k "streamlit run dashboard.py"

echo ✅ 실행 완료! 이 창은 닫으셔도 됩니다.
