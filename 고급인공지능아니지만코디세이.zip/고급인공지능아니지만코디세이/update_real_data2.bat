@echo off
chcp 65001 >nul
cd /d "C:\Users\skrkt\Desktop\고급인공지능\2학기\green-idc\green-idc"
set PYTHONPATH=.

:: 아래에 반드시 "Decoding" 버전 인증키를 넣으세요 (% 기호가 없는 형태)
set WEATHER_API_KEY=kDAOBXWkloTgzYhZT9Mf6MnNop1ew5A3z0FBFplKMR+F4H3liAuNsBNkrwpywkSAR3NaVGuGcy6bCayLfYN3GA==

echo ================================================
echo   Green IDC - 실데이터 갱신 / 모델 재학습 및 검증
echo ================================================
echo.

echo [1/4] 실제 날씨 데이터 받는 중...
python src\data\fetch_real_weather.py --config configs\base.yaml --station 119
if errorlevel 1 (
    echo.
    echo [오류] 1단계 실패. 위 에러 메시지를 확인하세요.
    pause
    exit /b 1
)

echo.
echo [2/4] 시계열 재생성 중...
python src\simulator\generate_dataset.py --config configs\base.yaml
if errorlevel 1 (
    echo.
    echo [오류] 2단계 실패. 위 에러 메시지를 확인하세요.
    pause
    exit /b 1
)

echo.
echo [3/4] AI 모델 재학습 중...
python src\ml\train.py
if errorlevel 1 (
    echo.
    echo [오류] 3단계 실패. 위 에러 메시지를 확인하세요.
    pause
    exit /b 1
)

echo.
echo [4/4] MPC 제어 절감률(10%% 이상) 검증 중...
python src\evaluation\validate_mpc_vs_rule_based.py
if errorlevel 1 (
    echo.
    echo [오류] 4단계 실패. 위 에러 메시지를 확인하세요.
    pause
    exit /b 1
)

echo.
echo [완료] 데이터 갱신, 모델 학습 및 MPC 검증이 모두 끝났습니다.
echo 이제 run_green_idc3.bat 으로 서버/대시보드를 실행하세요.
pause