@echo off
:: 터미널 창 한글 깨짐 방지
chcp 65001 >nul

:: 프로젝트 폴더 경로로 이동
cd /d "C:\Users\skrkt\Desktop\고급인공지능\2학기\green-idc\green-idc"

echo 🚀 Green IDC 시스템을 가동합니다...

:: 1. FastAPI 백엔드 실행 (새 터미널 창 띄우기)
start "Green IDC - FastAPI Backend" cmd /k "uvicorn src.main:app --reload"

:: 백엔드가 켜질 시간을 2초 정도 기다려줍니다 (선택 사항)
timeout /t 2 /nobreak >nul

:: 2. Streamlit 대시보드 실행 (새 터미널 창 띄우기)
start "Green IDC - Streamlit Dashboard" cmd /k "streamlit run dashboard.py"

echo ✅ 실행 완료! 이 창은 닫으셔도 됩니다.